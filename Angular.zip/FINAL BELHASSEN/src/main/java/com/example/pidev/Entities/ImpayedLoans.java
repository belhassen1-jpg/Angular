package com.example.pidev.Entities;

import javax.persistence.*;


//@Entity
//@Table(name ="impayed_loans")
//public class ImpayedLoans extends DetailsLoans {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Column(name="ID")
//    private Integer ID ; // clé primaire
//
//}
