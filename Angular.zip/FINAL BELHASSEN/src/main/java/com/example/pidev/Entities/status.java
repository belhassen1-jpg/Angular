package com.example.pidev.Entities;



public enum status {
    PAYED,NOTPAYED,EXPIRED
}

