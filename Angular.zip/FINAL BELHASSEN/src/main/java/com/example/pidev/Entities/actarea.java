package com.example.pidev.Entities;


public enum actarea {
    llal,nnn,vv
}
