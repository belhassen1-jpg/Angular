package com.example.pidev.Entities;

public enum TransactionState {
    VALIDATED,
    PENDING,
    CANCELED
}
