package com.example.pidev.Entities;


public enum Act {
    owner,partner;
}
